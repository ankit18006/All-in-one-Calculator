package com.example.all_in_one_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}