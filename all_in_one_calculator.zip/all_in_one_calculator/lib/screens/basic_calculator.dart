import 'package:flutter/material.dart';

class BasicCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Basic Calculator'),
    );
  }
}