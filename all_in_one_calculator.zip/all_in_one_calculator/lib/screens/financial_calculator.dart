import 'package:flutter/material.dart';

class FinancialCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Financial Calculator'),
    );
  }
}