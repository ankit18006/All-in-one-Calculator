import 'package:flutter/material.dart';

class ScientificCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Scientific Calculator'),
    );
  }
}